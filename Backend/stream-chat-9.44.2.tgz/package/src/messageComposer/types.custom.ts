export interface CustomTextComposerSuggestion {}
